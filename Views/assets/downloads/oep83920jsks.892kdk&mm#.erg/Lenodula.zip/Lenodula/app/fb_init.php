<?php 
	require_once "src/facebook-sdk-v5/autoload.php";

	session_start();

	$fb = new Facebook\Facebook([
  		'app_id' => '244978716373393', // Replace {app-id} with your app id
  		'app_secret' => '600bcf8797c281b8d3cc2e1542907c42',
  		'default_graph_version' => 'v2.2',
  	]);

 ?>