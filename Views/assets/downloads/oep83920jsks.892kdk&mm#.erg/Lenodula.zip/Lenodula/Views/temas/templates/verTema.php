<div id="some_activity">
	
</div>
<div id="centralSection">
	<article id="main">
		<div id="indexHeader" class="divHeader">
			<i class="material-icons">chrome_reader_mode</i>
			<h1><?= $titulo; ?></h1>
		</div><br>
		<div id="body_article">
			 <div id="header_body_article">
			 	<?php
			 		if($foto == 'none'):
			 			$ur = "/Views/template/images/account_circle.svg";
			 		else:
			 			$ur = "/Views/template/images/pictures/".$foto;		
			 		endif;
			 	 ?>
			 	 <div style="background-image:url(<?= $ur; ?>);"></div>
			 	<span>&nbsp;<?= print $name; ?></span>
			 <?php 
				if($id_usuario == $_SESSION['userSesion']['id']):
			 ?>
			<a href="/temas/editar/<?= $controlador->funcion('normalize', $titulo).'.'.$dats['id'];  ?>" class="href_action"><i id='edt_tems' class="material-icons">edit</i></a>
			<?php 
				else:
			?>
			<span id="love_tem"><b><?= $likes; ?></b>&nbsp;<i class="material-icons">favorite</i></span>
			<?php		
				endif;
			 ?>
			</div>
			<?php 
				if($contenido != '&lt;br&gt;'):
			?>
				<div id="theme_article_section">
			<?php
					print html_entity_decode($contenido);
			?>
				</div>

				<?php 
					if($nivel == 1):

 						$pos_res = array('idu' => $_SESSION['userSesion']['id'], 'idt' => $dats['id'], 'ti' => $controlador->funcion('normalize', $titulo));
 						$pos_res = base64_encode(json_encode($pos_res));
				 ?>
				<br><br><button class=" btn btnPublish send_exam" id="<?= $pos_res; ?>"><i class="material-icons ico">send</i>&nbsp;TERMINAR Y ENVIAR</button><br><br><hr color="F8F8F8">
				<?php
				?>
				<script type="text/javascript" src="/Views/template/js/editor.js"></script>
				<?php
					endif;
				?>
			<br><hr color='F8F8F8'><span class="timestamp"><i class="material-icons">watch_later</i>&nbsp;Última Modificación: <?= $controlador->funcion('alfa_months', $fecha_p); ?></span>
			<?php 
					if($view_tema == 0):
			?>
			<br><br>&nbsp;<button class="btn btnRegular read_tema" id="<?= $dat_tema; ?>"><i class="material-icons ico ico_btn">done_all</i>&nbsp;<span>Marcar como leído</span></button>
			<?php	
					else:
			?>
			<br><br>&nbsp;<button class="btn btnRegular"><i class="material-icons ico ico_btn">check_circle</i>&nbsp;<span>Leído</span></button>
			<?php			
					endif;
			?>
			<button class="btn btnEdit" id="new_event_tema"><i class="material-icons ico ico_btn">event</i>&nbsp;<span>Agendar</span></button>
			<?php
				else:
			?>
			<i class="material-icons img_empty">web</i>
			<?php
				endif;
			 ?>
		</div>
		<hr color="F8F8F8">

		<?php 
			if($nivel == 0):
				new Views\Foro_topic($dats['id'], $permiso_a, $controlador->funcion('normalize', $titulo), $lista_archivos, $page, $id_usuario, $fecha_limite, $hora_limite);
			endif;

			$nomev = $titulo." (Tema)";
			$frmEv = true;
			include_once(ROOT."Views/agendas/templates/frmEvent.php");	
		 ?>
		 <script type="text/javascript" src="/Views/template/js/base64ende.js"></script>
	</article>
</div>