<div id="some_activity">
	
</div>
<div id="centralSection">
	<article id="main">
		<div id="indexHeader" class="divHeader">
			<i class="material-icons">edit</i>
			<h1>Editar tema</h1>
		</div><br>
		<div id="divEditTema">
			<h2>"<?= $titulo; ?>"</h2>
			<p>Última modificación:&nbsp;<?= $controlador->funcion('alfa_months',$fecha_p); ?></p>
			<form class="frm" method="post" action="" id="frmPubTema">
				<br><label class="frmlbl" for="titulo">Título del tema</label><br>
				<input type="text" class="inptxt" id="titulo" name="titulo" value="<?= $titulo; ?>"><br>
				<br><br><label class="frmlbl" for="tags">*Opcional, Palabras Clave (escribe palabras clave y presiona Enter)</label><br>
				<div id="insert_tags">
					<?php 
						$tags_caps = explode(",", $tags);
						foreach ($tags_caps as $captg):
							if($captg != ""):
					?>
						<span><?= $captg; ?><span class="del_tag"><b>x</b></span></span>
					<?php
							endif;	
						endforeach;
					 ?>
					<input type="text" id="tags" name="tags" value="" autocomplete="off">
				</div><br>
				<input type="hidden" id="tags_hidden" name="tags_hidden" value="<?= $tags; ?>">
				<br><label class="frmlbl" for="fecha_limite_respuesta">Fecha límite para responder</label><br>
				<input type="date" class="inpdate" id="fecha_limite_respuesta" name="fecha_limite_respuesta" value="<?= $fecha_limite; ?>"><br>
				<br><label class="frmlbl" for="hora_limite_respuesta" id="hrlresp">Hora límite</label><br>
				<input type="time" class="inptime" id="hora_limite_respuesta" name="hora_limite_respuesta" value="<?= $hora_limite; ?>" disabled="disabled"><br>
				<br><label class="frmlbl" for="permiso_archivo">¿Puede subir archivos el usuario?</label><br><br>
				<div class="contSelect">
 		 		<select name="permiso_archivo" id="permiso_archivo">
 		 			<option>¿Permitir archivos?...</option>
 		 			<option <?php if($permiso_a == 1) print "selected"; ?>>Sí</option>
 		 			<option <?php if($permiso_a == 0) print "selected"; ?>>No</option>
 		 		</select>
 		 		</div><br>
 		 		<label class="frmlbl" for="titulo">*Opcional, Marcar si el tema es un examen...</label><br>
 		 		<input type="checkbox" name="nivel_tema" value="1" id="nivel_tema" <?= $check; ?>><br><br>
 		 		<a class="underl href_action" href="/temas/ver/<?= $argumento; ?>"><p>VER PUBLICACIÓN <i class="material-icons">visibility</i></p></a>
 		 		<?php
 		 			$p = explode(".", $argumento); 
 		 			$post_tema = array('id' => $p[1], 'ti' => $p[0], 'pt' => 'pt');
 					$post_tema = base64_encode(json_encode($post_tema));
 		 		 ?>
 		 		<input type="hidden" id="post_dats_tema" name="post_dats_tema" value="<?= $post_tema; ?>">
			</form>
			<?php 
				new Views\Editor('root', ($contenido), $lista_archivos, 'comentar', 'files_tut');
			 ?>
			
		</div><br>
		<script type="text/javascript" src="/Views/template/js/base64ende.js"></script>
	</article>
</div>