<?php 
	$res = $callback_datos;

	if($res == "false"){
		include_once(INDEX);
	}


 ?>