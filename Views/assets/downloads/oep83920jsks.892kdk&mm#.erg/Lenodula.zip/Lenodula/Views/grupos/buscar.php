<?php 
	
	include_once("templates/default.php");

	include_once(MSG."spinner.php");

 ?>