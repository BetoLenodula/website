<?php 
	
	include_once("templates/chartCursosAvance.php");
	include_once(MSG."spinner.php");

 ?>