<div id="some_activity">
	
</div>
<div id="centralSection">
	<article id="main">
		<div class="divHeader" id="indexHeader">
			<i class="material-icons">score</i>
			<h1>Avances</h1>
		</div>

		<div id="divAvances">
			<a href="/usuarios/perfil/<?= $argumento; ?>" class="href_action underl inline">
			<span>VER PERFIL</span>
			<i class="material-icons">launch</i>
			</a><br><br><br>
		<?php 
			if($callback_datos->num_rows > 0):
			 while($r = $callback_datos->fetch_array()):
				$perc = ceil(100 * $r['numero_temas_vistos'] / $r['numero_temas']);
				if($perc == 0):
					$perc = '00';
				endif;
		?>
		<div class="div_avance">
			<div class="div_inf_avance">
				<a href="/temas/listar/<?= $r['id_curso']; ?>" class="underl href_action inline">
					<i class="icon-logo"></i>
					<p>&nbsp;<?= $r['nombre_materia_curso']; ?></p>
				</a>
			</div>
			<div class="div_chart_avance">
				<meter class="meter_courses" min="0" max="<?= $r['numero_temas']; ?>" value="<?= $r['numero_temas_vistos']; ?>" ></meter>
				<span><?= $perc."%"; ?></span>
			</div>
		</div>
		<?php		
			 endwhile;
			else:
		?>
			<i class="material-icons img_empty">filter_none</i>
			<p class="advice">Este usuario no tiene ningún curso aún!!</p>
		<?php
			endif;
		 ?>
		</div>
	</article>
</div>