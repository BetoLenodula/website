<?php 
	
	include_once('templates/verMsgs.php');
	include_once(MSG."spinner.php");

 ?>