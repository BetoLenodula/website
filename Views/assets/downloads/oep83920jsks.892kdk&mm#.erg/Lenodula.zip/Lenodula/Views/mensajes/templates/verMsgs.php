<div id="some_activity">
	
</div>
<div id="centralSection">
	<article id="main">
		<div id="indexHeader" class="divHeader">
			<i class="material-icons">mail</i>
			<h1>Mensajes</h1>
		</div><br>
		<div id="divViewMsgs">
			<?php 
				if(!empty($callback_datos)):
				  foreach($callback_datos as $datos):
			?>
			<a href="/usuarios/perfil/<?= $datos['ide']; ?>?msg=true" class="href_action">
			<div class="div_b_msgs">
				<div class="pic_b_msgs">
					<div style="<?php if($datos['ids'] == 'FB')print "background-image: url(https://graph.facebook.com/$datos[ide]/picture?type=large)";?>">
						<?php 
						if($datos['fot'] == 'none'){
						?>
						<img src="/Views/template/images/account_circle.svg" alt="<?= $datos['nom']; ?>_default">
						<?php 
						}
						if($datos['fot'] != 'none' && $datos['ids'] != 'FB'){
			
						?>
						<img src="/Views/template/images/pictures/<?= $datos['fot'];?>" alt="<?= $datos['nom']; ?>_imagen">
						<?php
						}
						?>
					</div>
				</div>
				<div class="cont_b_msgs">
					<span>&nbsp;<?= $datos['nom']; ?></span>
				</div>
				<div class="info_b_msgs">
					<div class="envel_div">
					<i class="material-icons envel">mail</i>
					<div class="notround"></div>
					</div>
				</div>
			</div>
			</a>
			<?php
				  endforeach;
				else:
			?>

			<i class="material-icons img_empty">mail_outline</i>
			<p class="advice">No tienes mensajes!!</p>
			<?php		
				endif;
			 ?>
		</div>
	</article>
</div>