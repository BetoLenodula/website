<?php 
	$res = $callback_datos;
	
	include_once(INDEX);
	include_once(MSG."error.php");

 ?>