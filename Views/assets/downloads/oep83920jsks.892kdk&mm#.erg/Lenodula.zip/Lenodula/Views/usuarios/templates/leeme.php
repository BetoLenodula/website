<div id="some_activity">
	
</div>
<div id="centralSection">
	<article id="main">
		<div id="indexHeader" class="divHeader">
			<i class="icon-logo"></i>
			<h1>Leeme</h1>
		</div>
		<br><br>
		<div id="main_logo"><i class="icon-logo logo_medium"></i>Len<i class="icon-logo"></i>dula</div><br>
		<span class="lema">Piensa, Organiza, Comparte</span><br><br>
		<p class="quote quote1">
			Para acceder a este sistema tómate tu tiempo para crear una cuenta.
			El sistema requiere una autentificación.
			Al crear tu cuenta podrás crear un id de usuario único y podras acceder a los foros, grupos y temas publicados por Tutores de curso y Usuarios.
		</p>
		<br><br>
		<p class="quote quote2">
			Inicia Sesión en el enlace de la barra de navegación superior.
			Rellena el Formulario de Registro con tus datos.
			El sistema te enviará un correo para verificar que tu dirección sea correcta.
			(Por eso es recomendable utilizar un correo real, ya que de lo contrario no te será posible acceder al sistema).
			Lee el correo y confirma tu registro en el sistema. Si por alguna razón <u>no recibes el correo</u> en la bandeja de entrada, <u>revisa la bandeja de correo no deseado.</u>
			Tu registro será confirmado y cumpliendo este requisito podras acceder e iniciar sesión con tu cuenta, ya sea de Tutor o Usuario.
			Seleccionamos el grupo o grupos en los cuales querramos participar y el Tutor creador del curso será quien dará el pase al Usuario.
			Si algún grupo en particular te solicita una "contraseña de acceso" utiliza la que te proporcione el Tutor. Con esto cumplirás ese requisito.
			A partir de ese momento sólo necesitarás utilizar tu correo y contraseña creada especialmente para este sistema.
			Cabe señalar que también tienes acceso utilizando los datos de tu cuenta de facebook.
		</p>
		<br><br>
		<p class="quote quote1">
			Puntos: <br>
			A medida que tus Puntos incrementen, se notifican para reflejar tu nivel de actividad.
			Acumulas Puntos al recibir "Puntuación" de parte del Tutor y aportar con los demás usuarios en los comentarios y los temas. 
		</p>
		<br><br>
	</article>
</div>