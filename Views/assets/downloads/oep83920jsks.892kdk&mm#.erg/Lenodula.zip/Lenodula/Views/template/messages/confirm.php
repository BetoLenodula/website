		<div class="confirm_back">
		<div class="confirm box">
			<i class="material-icons cerrarBox">closed</i><br><br>
			<span class="date_event"></span><br><br>
			<p>¿Quieres Ver Los Eventos o Crear un Nuevo Evento?</p><br>
			<button id="list_view_events"><i class="material-icons">event_note</i>&nbsp;Ver Eventos</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<button id="conf_new_event"><img src="/Views/template/images/calendario.svg" alt="eventos" width="19">&nbsp;Nuevo Evento</button><br>
		</div>
		</div>