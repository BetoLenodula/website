<div class="advice box">
	<i class="material-icons">check_box</i>
	<p><?php print $res; ?></p><br>
	<button class="cerrarError cerrsave">CERRAR</button>
</div>