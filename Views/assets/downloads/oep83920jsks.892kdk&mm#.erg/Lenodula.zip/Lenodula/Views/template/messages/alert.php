		<div class="alert_back">
		<div class="alert box">
			<i class="material-icons">lightbulb_outline</i>
			<p></p><br>
			<button class="cerrar_shadow cerrsave">CERRAR</button>
		</div>
		</div>