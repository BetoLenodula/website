<div class="error box">
	<i class="material-icons">error</i>
	<p><?php print $res; ?></p><br>
	<button class="cerrarError cerrsave">CERRAR</button>
</div>