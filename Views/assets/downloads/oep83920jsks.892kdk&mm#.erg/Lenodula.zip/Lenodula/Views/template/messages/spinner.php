<div class="spinner box">
	<img src="/Views/template/images/loading.gif" width="25">
	<p>Procesando ...</p>
</div>